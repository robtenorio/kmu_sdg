library(tidyverse)

doc_goals <- read_csv("../Global Indicator Framework_A.RES.71.313 Annex.csv", skip = 3) %>% select(2:3) %>%
  setNames(c("goals", "indicators"))

doc_sectors <- read_csv("../sectors.csv") %>% mutate(sectors = str_to_lower(SECTOR_NME))

sectors <- doc_sectors["sectors"] %>% unique %>% na.omit %>% filter(!grepl("^(\\(historic\\))", sectors))

str_extract_all(doc_sectors[["SECTOR_NME"]], "^(\\(Historic\\))") %>% na.omit

doc_themes <- read_csv("../themes.csv") %>% select("THEME_NME") %>% unique %>% na.omit

goals <- str_extract_all(doc_goals[["goals"]], "^(Goal)[:space:][:digit:]{1,2}[.].*$") %>% unlist %>% na.omit %>%
  str_replace_all("^(Goal)[:space:][:digit:]{1,2}[.][:space:]", "")

str_extract_all(doc[["goals"]], "^(Goal).*") %>% unlist %>% na.omit


final <- tibble(strings = c(goals, indicators))

write_csv(final, "../sdg_goals_indicators.csv", col_names = FALSE)
