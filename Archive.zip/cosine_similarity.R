library(tidytext)
library(tidyverse)
library(text2vec)
library(zeallot)

df <- read_csv("sector_theme_indicator.csv")

all_terms <- stack(df)[["values"]] %>% unique %>% na.omit %>% .[1:500]

prep_fun <- function(x) {
  x %>%
    str_to_lower %>%
    str_replace_all("[^[:alnum:]]", " ") %>%
    str_replace_all("\\s+", " ")
}

tok_fun <- word_tokenizer

it_all <- itoken(all_terms,
             preprocessor = prep_fun,
             tokenizer = tok_fun)

vocab <- create_vocabulary(it_all, stopwords = tidytext::stop_words$word)

vectorizer <- vocab_vectorizer(vocab)

### prepare vectors of documents
c(sectors, themes, indicators) %<-% map(df, . %>% unique %>% na.omit %>% .[1:500])

tf_idf_fun <- function(x) {
  
  it <- itoken(x, 
               preprocessor = prep_fun,
               tokenizer = tok_fun)
  
  dtm = create_dtm(it, vectorizer)
  
  tfidf = TfIdf$new()
  
  dtm_tfidf = fit_transform(dtm, tfidf)
  
}

c(sectors_tf_idf, themes_tf_idf, indicators_tf_idf) %<-% map(c(sectors, themes, indicators), tf_idf_fun)

sectors_tf_idf <- tf_idf_fun(sectors)



### Now find cosine similarities between indicators and sectors/themes
indicators_themes <- sim2(indicators, themes, 
                          method = "cosine")

indicators_sectors <- sim2(indicators, sectors,
                           method = "cosine")

table(indicators_themes[1,])
ind <- which.max(indicators_themes[1,])
names(indicators_themes[1,ind])
colnames(themes)[18]

table(dtm_tfidf[1,])

which(dtm_tfidf[1,] > 0)

ind <- which.max(dtm_tfidf[1,])
names(indicators_themes[1,ind])
