library(textstem)
library(tidytext)
library(tidyverse)
library(text2vec)
library(zeallot)

df <- read_csv("sector_theme_indicator.csv")

stop_words <- unique(get_stopwords()[["word"]])

prep_fun <- function(x) {
  x <- x %>% str_to_lower %>% 
    str_replace_all("[^[:alnum:]]", " ") %>%
    str_replace_all("\\s+", " ") %>%
    unique %>%
    na.omit %>%
    .[1:500]
  
  stops_lemma <- function(x) {
    split_x <- as.vector(str_split(x, " ", simplify = TRUE))
    stop_x <- split_x[!split_x %in% stop_words]
    lemma_x <- lemmatize_words(stop_x)
    str_c(lemma_x, collapse = " ")
  }
  
map(x, stops_lemma) %>% unlist
  
}

all_terms <- stack(df)[["values"]] %>% prep_fun

tok_fun <- word_tokenizer

it_all <- itoken(all_terms,
             tokenizer = tok_fun)

vocab <- create_vocabulary(it_all)

vectorizer <- vocab_vectorizer(vocab)

### prepare vectors of documents

c(sectors, themes, indicators) %<-% map(df, prep_fun)

tf_idf_fun <- function(x) {
  
  it <- itoken(x, tokenizer = tok_fun)
  
  dtm <- create_dtm(it, vectorizer)
  
  tfidf <- TfIdf$new()
  
  dtm_tfidf <- fit_transform(dtm, tfidf)
  
}



sectors_tf_idf <- tf_idf_fun(sectors)
themes_tf_idf <- tf_idf_fun(themes)
indicators_tf_idf <- tf_idf_fun(indicators)


### Now find cosine similarities between indicators and sectors/themes
indicators_themes <- sim2(indicators_tf_idf, themes_tf_idf, 
                          method = "cosine")

indicators_sectors <- sim2(indicators, sectors,
                           method = "cosine")

table(indicators_themes[10,])
ind <- which.max(indicators_themes[10,])
indicators[10]
themes[ind]

table(dtm_tfidf[1,])

which(dtm_tfidf[1,] > 0)

ind <- which.max(dtm_tfidf[1,])
names(indicators_themes[1,ind])
